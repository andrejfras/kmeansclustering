mpjrun.sh -np 4 -jar target/K-means-clustering-1.0-SNAPSHOT-jar-with-dependencies.jar $@

